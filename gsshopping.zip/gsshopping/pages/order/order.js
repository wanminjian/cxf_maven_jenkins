// pages/order/order.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order: [
      {
        shop_logo: '../resources/image/shop.png',
        shop_name: '夜猫商城',
        order_status: '订单已完成',
        order_info: [
          {
            shop_name: '商品信息苹果1',
            shop_count: 1
          },
          {
            shop_name: '商品苹果1',
            shop_count: 3
          },
        ],
        total_size: 2,
        total_money: 25,
        order_comm: false
      },
      {
        shop_logo: '../resources/image/shop.png',
        shop_name: '夜猫商城',
        order_status: '订单已完成',
        order_info: [
          {
            shop_name: '商品信息苹果1',
            shop_count: 1
          },
          {
            shop_name: '商品苹果1',
            shop_count: 3
          },
        ],
        total_size: 2,
        total_money: 25,
        order_comm: false
      },
      {
        shop_logo: '../resources/image/shop.png',
        shop_name: '夜猫商城',
        order_status: '订单已完成',
        order_info: [
          {
            shop_name: '商品信息苹果1',
            shop_count: 1
          },
          {
            shop_name: '商品苹果1',
            shop_count: 3
          },
        ],
        total_size: 2,
        total_money: 25,
        order_comm: true
      },
      {
        shop_logo: '../resources/image/shop.png',
        shop_name: '夜猫商城',
        order_status: '订单已完成',
        order_info: [
          {
            shop_name: '商品信息苹果1',
            shop_count: 1
          },
          {
            shop_name: '商品苹果1',
            shop_count: 3
          },
        ],
        total_size: 2,
        total_money: 25,
        order_comm: true
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //使用setTimeout模拟下拉刷新
    setTimeout(() => wx.stopPullDownRefresh(), 1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})