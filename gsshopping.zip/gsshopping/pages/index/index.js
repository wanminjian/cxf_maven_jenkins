//index.js
//获取应用实例
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    goods: [
      {
        img: '../resources/image/milk.jpg',
        price: 125
      },
      {
        img: '../resources/image/milk.jpg',
        price: 125
      },
       {
        img: '../resources/image/milk.jpg',
        price: 125
      },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       },
       {
         img: '../resources/image/milk.jpg',
         price: 125
       }
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.checkSession({
      success: function () {
        console.log("当前session ");
      }
    })
    /**
     * 获取授权弹窗
     */
    wx.getSetting({
      success(res) {
        console.log(11112222, res)
        if (!res.authSetting['scope.userLocation']) {
          wx.authorize({
            scope: 'scope.userLocation',
            success() {
              wx.getLocation();
            },
            fail(res) {
              console.log(2333, '未授权')
            }
          })
        }

      },
      fail(res) {
        console.log('未授权')
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //使用setTimeout模拟下拉刷新
    setTimeout(() => wx.stopPullDownRefresh(), 1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 处理页面跳转逻辑
   */
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs',
    })
  }

})
