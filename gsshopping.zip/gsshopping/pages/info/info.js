// pages/info/info.js

//获取应用实例
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    console.log(this.data)
  },
  /**
   * 获取登陆用户信息
   */
  handleLogin: function (e) {
    var page = this
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        console.log(res.code)
        let APPID = 'wx2d25e7fe7f8fc0a9';
        let SECRET = '012e3ce5d4fc7f359f9eb69bbd201165';
        let JSCODE = res.code;
        if (res.code) {
          //发起网络请求,获取session_key
          wx.request({
            url: 'https://api.weixin.qq.com/sns/jscode2session?appid=' + APPID + '&secret=' + SECRET + '&js_code=' + JSCODE + '&        grant_type=authorization_code',
            success: function (res) {
              console.log(1212121, res.data)
              wx.getUserInfo({
                success: function (e) {
                    //this作用域问题
                    page.setData({
                      userInfo: e.userInfo,
                      hasUserInfo: true
                    })
                }
              })

            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
  },
  /**
   * 事件处理函数,页面内部跳转
   *
   */
  bindViewTap: function () {
    wx.navigateTo({
      url: '../address/address'
    })
  }
})