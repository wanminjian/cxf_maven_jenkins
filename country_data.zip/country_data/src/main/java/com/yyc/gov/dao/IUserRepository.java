package com.yyc.gov.dao;

import java.util.List;
import java.util.Map;

public interface IUserRepository {
	
	/**
	 * 根据用户名查询用户信息
	 * @param username
	 * @return
	 */
	public Map findUserByName(String username);

	/**
	 * 查询用户列表
	 * @param username
	 * @return
	 */
	public List findUserList();
	
	/**
	 * 查询患病用户列表
	 * @param area 区域
	 * @return 
	 */
	public List findSickUser(String area);
	
	/**
	 * 查询体检用户列表
	 * @param area 区域
	 * @return 
	 */
	public List findExamUser(String area);
	
	/**
	 * 查询下级乡镇体检人数
	 * @param area 区域
	 * @return 
	 */
	public Map findExamCount(String area);
	
	/**
	 * 长期用药人数
	 * @param area 区域
	 * @return 
	 */
	public List findPharmacyCount(String area);
	
	
	/**
	 * 致残分类列表
	 * @param 
	 * @return 
	 */
	public List findDisableBySick(String area,String reaon);
	
	

	/**
	 * 根据area获取各乡镇人数
	 * @param 
	 * @return 
	 */
	public Map findUserByAraea(String area);
	
	/**
	 * 根据疾病类型获取人数
	 * @param 
	 * @return 
	 */
	public List findUserByDisease(String area);
	
	/**
	 * 查询帮扶人列表
	 * @param 
	 * @return 
	 */
	public List findHelpUser();
	
	public List findUserInfo(String area,String username,String age,String phone,String help,String idcard);
	
	public List findUserById(String id);

	public List findByName(String name) ;

    public List findAraeaByAraeaCode(String code) ;

}

