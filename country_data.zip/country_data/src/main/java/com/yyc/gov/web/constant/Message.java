package com.yyc.gov.web.constant;

public class Message {
	public static final String USERNAME = "用户名";
	
	public static final String PASSWORD = "密码";
	
	public static final String CHECK_CODE_FAIL = "验证码错误";

	public static final String LOGIN_SUCCESS = "登陆成功";
	
	public static final String LOGOFF_SUCCESS = "注销成功";
	
	public static final String LOGOFF_FAIL = "注销失败";
	
	public static final String LOGIN_FAIL = "用户名或者密码错误";
	
	public static final String RESULT_SUCCESS = "查询成功";

	public static final String RESULT_FAIL = "查询无数据";

}
