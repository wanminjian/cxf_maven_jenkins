package com.yyc.gov;

import com.yyc.gov.util.QRCode;

public class TestQRCode {

	public static void main(String[] args) {
		 
		//生成二维码
		 String imgPath = "E:/qrCode.png";
		 String encoderContent = "http://www.baidu.com"; 

		 QRCode.encoderQRCode(encoderContent, imgPath, "png");
		 System.out.println("encoder success!!!");
		 
		 //解析二维码
		 String imgPath2 = "E:/qrCode.png";
		 String qrCon = QRCode.decoderQRCode(imgPath2);
		 System.out.println("decoder success!!!");
		 System.out.println("二维码内容为:" + qrCon);
	}
}

