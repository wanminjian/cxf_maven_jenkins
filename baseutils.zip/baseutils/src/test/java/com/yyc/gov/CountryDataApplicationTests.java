package com.yyc.gov;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.yyc.gov.dao.UserRepository;
import com.yyc.gov.service.IUserBiz;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CountryDataApplicationTests {

	@Autowired
	private IUserBiz userBiz;

	@Autowired
	private UserRepository userRepository;

	@Test
	public void contextLoads() {
	}

	@Test
	public void save() {
		userBiz.save();
	}

	@Test
	public void test() {
		List<Object[]> rows = userRepository.findRR("11");
		for (Object[] row : rows) {
			System.out.println("username = " + row[0]);
			System.out.println("password = " + row[1]);
		}

	}

	@Test
	public void test2() {
		List<Object[]> rows = userRepository.findFF("group1");
		for (Object[] row : rows) {
			System.out.println("username = " + row[0]);
			System.out.println("password = " + row[1]);
		}

	}
}
