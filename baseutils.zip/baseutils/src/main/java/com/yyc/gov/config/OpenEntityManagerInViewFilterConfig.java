package com.yyc.gov.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;

/**
 * Lazy加载配置openEntityManagerInView
 * @author mandy
 *
 */
@Configuration
public class OpenEntityManagerInViewFilterConfig {
	
	@Bean
	public FilterRegistrationBean<OpenEntityManagerInViewFilter> openEntityManagerInViewFilter() {
		OpenEntityManagerInViewFilter openSession = new OpenEntityManagerInViewFilter();
		FilterRegistrationBean<OpenEntityManagerInViewFilter> bean = new FilterRegistrationBean<OpenEntityManagerInViewFilter>();
		bean.setFilter(openSession);
		bean.addUrlPatterns("/*");
		return bean;
	}
	
}
