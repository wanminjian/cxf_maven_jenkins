package com.yyc.gov.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.yyc.gov.dao.GroupRepository;
import com.yyc.gov.dao.UserRepository;
import com.yyc.gov.entity.po.Group;
import com.yyc.gov.entity.po.User;

/**
 * Lazy
 * @author mandy
 *
 */
@Service
@Transactional
public class UserBiz implements IUserBiz{
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private GroupRepository groupRepository;

	@Transactional(readOnly=true)
	@Override
	public User getUserInfo() {
		User result = userRepository.findByGroup_GroupNameAndUsername("group1","22");
		return result;
	}

	/**
	 * 测试save关联实体的级联问题
	 */
	@Transactional(propagation=Propagation.REQUIRED,isolation=Isolation.READ_COMMITTED)
	@Override
	public void save() {
		// TODO Auto-generated method stub
		User u = new User();
		u.setUsername("bba");
		u.setPassword("bba");
		Group g = new Group();
		g.setGroupName("g6");
//		u.setGroup(g);  //save多的一段
		g.getUsers().add(u);
		groupRepository.save(g); //save一的一段
//		u.setGroup(g);
//		userRepository.save(u);
	}

}
