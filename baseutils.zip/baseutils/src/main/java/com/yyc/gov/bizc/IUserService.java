package com.yyc.gov.bizc;

import java.util.List;
import java.util.Map;

public interface IUserService {
	
}
