package com.yyc.gov.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONUtil {
	
	private static Logger log = LoggerFactory.getLogger(JSONUtil.class);
	
	public static Map<String, String> jsonToMap(String strJSON) {
		Map<String, String> map = new HashMap<String, String>();
		ObjectMapper mapper = new ObjectMapper();
		
		try{
			map = mapper.readValue(strJSON, new TypeReference<HashMap<String,String>>(){});
		}catch(Exception e){
			log.warn("转换异常", e.getMessage());
		}
		return map;
	}
	
	/*public static void main(String[] args) {
		String json = "{\"name\":\"zitong\", \"age\":\"26\"}";
		System.out.println(jsonToMap(json));
	}*/
}
