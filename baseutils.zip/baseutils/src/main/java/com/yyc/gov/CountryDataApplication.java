package com.yyc.gov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.yyc.gov.dao.custom.CustomRepositoryFactoryBean;


@SpringBootApplication
@ServletComponentScan
@EnableCaching
@EnableJpaRepositories(repositoryFactoryBeanClass = CustomRepositoryFactoryBean.class) 
public class CountryDataApplication {
	public static void main(String[] args){
		System.setProperty("spring.devtools.restart.enabled", "true");
		SpringApplication.run(CountryDataApplication.class, args);
	}
}
