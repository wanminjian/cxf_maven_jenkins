package com.yyc.gov.dao.custom;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

/**
 * 自定义Repository实现Specification
 * 
 * @author mandy
 *
 */
public class CustomerSpecs {

	public static <T> Specification<T> byAuto(Class<T> c) {
		
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				Field[] field = c.getDeclaredFields();
				for (Field f : field) {
					System.out.println(f.getName() + "-----------" + f.getType());
					if(f.getType() == String.class){
						try {
							cb.like(root.get(f.getName()), "%"+ f.get(f.getName()).toString() +"%");
						} catch (IllegalArgumentException | IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				return cb.and(predicates.toArray(new Predicate[predicates.size()]));
			}
			
			public Object getValue(Object key){
				return null;
			}

		};
	}
	

}
