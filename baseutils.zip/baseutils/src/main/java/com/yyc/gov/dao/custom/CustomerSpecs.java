package com.yyc.gov.dao.custom;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.Attribute;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.SingularAttribute;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import com.yyc.gov.web.controller.UserController;

/**
 * 自定义Repository实现Specification
 * 
 * @author mandy
 *
 */
public class CustomerSpecs {

	private static Logger log = LoggerFactory.getLogger(CustomerSpecs.class);

	public static <T> Specification<T> byAuto(final EntityManager entityManager, final T t) {
		
		final Class<T> type = (Class<T>) t.getClass();
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				List<Predicate> predicates = new ArrayList<>();
				EntityType<T> entity =  entityManager.getMetamodel().entity(type);

				for (Attribute<T, ?> attr : entity.getDeclaredAttributes()) {
					Object attrValue = getValue(t, attr); // 获取属性值
					if (attrValue != null) {
						if (attr.getJavaType() == String.class) {
							if (!StringUtils.isEmpty(attrValue)) {
								predicates.add(cb.like(root.get(attribute(entity, attr.getName(), String.class)),
										pattern((String) attrValue)));
							}
						} else {
							predicates.add(cb.equal(root.get(attribute(entity, attr.getName(), attrValue.getClass())),
									 attrValue));
						}
					}
				}
				return predicates.isEmpty() ? cb.conjunction()
						: cb.and(predicates.toArray(new Predicate[predicates.size()]));
			}

			/**
			 * 获取属性值
			 * 
			 * @param e
			 * @param attr
			 * @return
			 */
			private <T> Object getValue(T t, Attribute<T, ?> attr) {
				Field field = ReflectionUtils.findField(type, attr.getName());
				field.setAccessible(true);
				return ReflectionUtils.getField(field, t);
			}

			/**
			 * 获取属性名
			 * 
			 * @param entity
			 * @param fieldName
			 * @param fieldClass
			 * @return
			 */
			private <E, T> SingularAttribute<T, E> attribute(EntityType<T> entity, String fieldName,
					Class<E> fieldClass) {
				return entity.getDeclaredSingularAttribute(fieldName, fieldClass);
			}
		};
	}

	/**
	 * 模糊查询
	 * 
	 * @param str
	 * @return
	 */
	private static String pattern(String str) {
		return "%" + str + "%";
	}

}
