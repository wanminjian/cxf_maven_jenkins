package com.yyc.gov.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.yyc.gov.dao.custom.CustomRepository;
import com.yyc.gov.entity.po.User;

@Component
public interface UserRepository extends CustomRepository<User, Long> {

	User findByGroup_GroupNameAndUsername(String GroupName,String username);
	
	@Query(value = "select username,password from User u where u.username like %:name%")
	List<Object[]> findRR(@Param("name") String name);
	
	/**
	 * JOIN联接查询
	 * @param name
	 * @return
	 */
	@Query(value = "select u.username,u.password from User u join u.group g where g.groupName like %:name%")
	List<Object[]> findFF(@Param("name") String name);
	
	
}	
