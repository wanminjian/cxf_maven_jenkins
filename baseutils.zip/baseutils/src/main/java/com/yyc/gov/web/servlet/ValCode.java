package com.yyc.gov.web.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.yyc.gov.util.EhcacheUtil;

/**
 * Servlet implementation class ValCode
 */
@WebServlet(name = "valCode", urlPatterns = { "/valCode" })
public class ValCode extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ValCode() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setDateHeader("Expires", -1);
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Content-Type", "image/jpeg");
		
		String uuid = request.getParameter("uuid");
		
		String base = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int length = 4, width = 80, height = 22;
		Random rd = new Random();
		String valcode = "";

		// 生成验证码
		for (int i = 0; i < length; i++) {
			valcode += base.charAt(rd.nextInt(base.length()));
		}
		
		// 存储验证码
		WebApplicationContext wc = WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
		EhcacheUtil ehcache = wc.getBean(EhcacheUtil.class);
		ehcache.put("User", uuid , valcode);
		
		// 绘制图片
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();

		// 填充底色
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.GRAY);
		g.drawRect(0, 0, width - 1, height - 1);

		for (int i = 0; i < 10; i++) {
			g.setColor(new Color(rd.nextInt(150) + 100, rd.nextInt(150) + 100, rd.nextInt(150) + 100));
			// g.drawLine(rd.nextInt(width), rd.nextInt(height),
			// rd.nextInt(width), rd.nextInt(height));
			g.fillOval(rd.nextInt(width), rd.nextInt(height), rd.nextInt(width), rd.nextInt(height));
		}
		for (int i = 0; i < length; i++) {
			Font font = new Font("", Font.BOLD, 20);
			g.setFont(font);
			g.setColor(new Color(rd.nextInt(150), rd.nextInt(150), rd.nextInt(150)));
			g.drawString(valcode.charAt(i) + "", (width / length) * i + 3, 20);
		}
		g.dispose();

		OutputStream output = response.getOutputStream();
		ImageOutputStream ios = ImageIO.createImageOutputStream(output);
		ImageIO.write(img, "jpeg", ios);
		ios.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
