package com.yyc.gov.web.controller;

import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yyc.gov.dao.UserRepository;
import com.yyc.gov.entity.po.User;
import com.yyc.gov.mapper.UserMapper;
import com.yyc.gov.service.IUserBiz;

@RestController
@RequestMapping(value = "/rest/user")
public class UserController {

	private static Logger log = LoggerFactory.getLogger(UserController.class);

	/*
	 * @Autowired private EhcacheUtil ehcacheUtil;
	 */
	@Autowired
	private IUserBiz userBiz;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserMapper userMapper;

	@RequestMapping(value = "/test")
	public User getTestUser() {
		User result = userBiz.getUserInfo();
		result.getGroup(); //Lazy加载
		log.info("findByCondition method completed");
		return result;
	}

	@RequestMapping(value = "/auto")
	public Page<User> getUser(User user) {
		Page<User> result = userRepository.findByCondition(user, PageRequest.of(0, 10));
		log.info("findByCondition method completed");
		return result;
	}

	@RequestMapping(value = "/auto2")
	public List<User> getUser2() {
		List<User> result = userMapper.getAll();
		log.info("findByCondition method completed");
		return result;
	}

	@RequestMapping("/uid")
	String uid(HttpSession session) {
		UUID uid = (UUID) session.getAttribute("uid");
		if (uid == null) {
			uid = UUID.randomUUID();
		}
		session.setAttribute("uid", uid);
		return session.getId();
	}

}
