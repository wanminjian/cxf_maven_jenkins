package com.yyc.gov.service;

import com.yyc.gov.entity.po.User;

public interface IUserBiz {
	public User getUserInfo();
	
	public void save();
}
