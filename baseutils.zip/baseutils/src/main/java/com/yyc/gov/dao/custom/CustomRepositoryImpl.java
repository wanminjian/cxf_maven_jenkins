package com.yyc.gov.dao.custom;

import static com.yyc.gov.dao.custom.CustomerSpecs.*;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

//自定义数据库接口实现
public class CustomRepositoryImpl <T,ID extends Serializable> extends SimpleJpaRepository<T,ID> implements CustomRepository<T,ID>{
	
	public CustomRepositoryImpl(Class<T> domainClass,EntityManager entityManager){
		super(domainClass,entityManager);
	}

	@Override
	public List<T> findByCondition(Class<T> c) {
		
		return this.findAll(byAuto(c));
	}
}
