package com.yyc.gov.dao.custom;

import static com.yyc.gov.dao.custom.CustomerSpecs.byAuto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

/**
 * 自定义数据接口实现
 * 
 * @author mandy
 *
 * @param <T>
 * @param <ID>
 */
public class CustomRepositoryImpl<T, ID extends Serializable> extends SimpleJpaRepository<T, ID>
		implements CustomRepository<T, ID> {

	private final EntityManager entityManager;

	public CustomRepositoryImpl(Class<T> domainClass, EntityManager entityManager) {
		super(domainClass, entityManager);
		this.entityManager = entityManager;
	}

	/**
	 * 实体类按条件自动查询
	 * 
	 * @param t
	 * @param pageable
	 *            分页
	 * @return
	 */
	@Override
	public Page<T> findByCondition(T t, Pageable pageable) {
		return findAll(byAuto(entityManager, t), pageable);
	}

}
