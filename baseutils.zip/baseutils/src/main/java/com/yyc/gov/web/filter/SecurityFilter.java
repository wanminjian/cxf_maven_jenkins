package com.yyc.gov.web.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.yyc.gov.util.EhcacheUtil;
import com.yyc.gov.util.JSONUtil;

import jodd.util.StringUtil;

@WebFilter
public class SecurityFilter implements Filter {

	private static Logger log = LoggerFactory.getLogger(JSONUtil.class);

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		log.info("过滤器destroy成功");
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain)
			throws IOException, ServletException {

		chain.doFilter(arg0, arg1);

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		log.info("过滤器init成功");
	}

}
