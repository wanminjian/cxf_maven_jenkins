package com.yyc.gov.web.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.yyc.gov.util.EhcacheUtil;
import com.yyc.gov.util.JSONUtil;

import jodd.util.StringUtil;

@WebFilter
public class SecurityFilter implements Filter {
	
	private static Logger log = LoggerFactory.getLogger(JSONUtil.class);
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		log.info("过滤器destroy成功");
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest) arg0;
		HttpServletResponse response = (HttpServletResponse) arg1;
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "*");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");

		String requestURI = request.getRequestURI();
		String param = request.getParameter("param");
		Map<String, String> map = JSONUtil.jsonToMap(param);
		String sessionId = map.get("sessionId");
		if (!requestURI.contains("login")) {
			if (!StringUtil.isBlank(sessionId)) {
				WebApplicationContext wc = WebApplicationContextUtils
						.getWebApplicationContext(request.getServletContext());
				EhcacheUtil ehcache = wc.getBean(EhcacheUtil.class);
				Object o = ehcache.get("User", sessionId); // 获取登陆用户信息
				if (o==null) {
					response.getWriter().write("登陆超时或者已注销");
				} else {
					chain.doFilter(request, response);
				}
			}else{
                response.getWriter().write("登陆超时");
            }
		} else {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		log.info("过滤器init成功");
	}

}
