package com.yyc.gov.dao;

import java.util.Map;

import com.yyc.gov.dao.custom.CustomRepository;
import com.yyc.gov.entity.po.User;

public interface IUserRepository extends CustomRepository<User, String> {

	/**
	 * 根据用户名查询用户信息
	 * 
	 * @param username
	 * @return
	 */
	public Map findByUsername(String username);

}
