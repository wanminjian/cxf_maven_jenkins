package com.yyc.gov.dao;

import org.springframework.stereotype.Component;

import com.yyc.gov.dao.custom.CustomRepository;
import com.yyc.gov.entity.po.Group;

@Component
public interface GroupRepository extends CustomRepository<Group, Long> {


}
