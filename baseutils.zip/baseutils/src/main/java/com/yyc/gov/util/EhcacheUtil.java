package com.yyc.gov.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

@Component
public class EhcacheUtil {

	@Autowired
	private CacheManager cacheManager;

	public void put(String cacheName, String key, Object value) {
		Cache cache = cacheManager.getCache(cacheName);
		cache.put(key, value);
	}

	public Object get(String cacheName, String key) {
		Cache cache = cacheManager.getCache(cacheName);
		ValueWrapper vw = cache.get(key);
        try {
            Object object = vw.get();
            return object;
        }catch (Exception e){
            return null;
        }
	}

	public Cache get(String cacheName) {
		return cacheManager.getCache(cacheName);
	}

	public void remove(String cacheName, String key) {
		Cache cache = cacheManager.getCache(cacheName);
		cache.evict(key);
	}

}
