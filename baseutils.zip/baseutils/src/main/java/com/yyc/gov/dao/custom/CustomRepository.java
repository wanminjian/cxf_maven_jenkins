package com.yyc.gov.dao.custom;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * 自定义Repository
 * 
 * @author mandy
 *
 * @param <T>
 * @param <ID>
 */

@NoRepositoryBean
public interface CustomRepository<T, ID extends Serializable>
		extends JpaRepository<T, ID>, JpaSpecificationExecutor<T> {
	
	public List<T> findByCondition(Class<T> c);
}