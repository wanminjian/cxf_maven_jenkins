package com.yyc.gov.dao.custom;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * 自定义Repository
 * 
 * @author mandy
 *
 * @param <T>
 * @param <ID>
 */

@NoRepositoryBean
public interface CustomRepository<T, ID extends Serializable>
		extends JpaRepository<T, ID>, JpaSpecificationExecutor<T> {
	
	/**
	 * 实体类按条件自动查询
	 * @param t
	 * @param pageable 分页
	 * @return
	 */
	public Page<T> findByCondition(T t,Pageable pageable);
}